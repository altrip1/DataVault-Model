USE [CMSDB]
GO

/****** Object:  Table [dbo].[SecurityPropertyValuationDetails]    Script Date: 16/01/2023 14:33:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SecurityPropertyValuationDetails](
	[OID] [dbo].[objectID] IDENTITY(1,1) NOT NULL,
	[Datecreated] [datetime] NOT NULL,
	[Version] [datetime] NOT NULL,
	[SecurityPropertyDetailsOID] [dbo].[objectID] NULL,
	[Valuation] [decimal](38, 5) NULL,
	[IsNexusValuation] [bit] NULL,
	[ValuationDate] [datetime] NULL,
	[SourceOID] [dbo].[objectID] NULL,
	[OtherSource] [dbo].[descriptionString] NULL,
	[ValuationMethodOID] [dbo].[objectID] NULL,
	[OtherValuationMethod] [dbo].[descriptionString] NULL,
	[ValuerNameOID] [dbo].[objectID] NULL,
	[ValuerContactName] [dbo].[descriptionString] NULL,
	[ValuerQuoteReceived] [decimal](38, 10) NULL,
	[ValuerAmountInvoiced] [decimal](38, 10) NULL,
	[ValuerChargeDate] [datetime] NULL,
	[IsSatisfactory] [bit] NULL,
	[DissatisfactionReasonOID] [dbo].[objectID] NULL,
	[OtherDissatisfactionReason] [dbo].[descriptionString] NULL,
	[IsCustomerFeePaid] [bit] NULL,
	[DraftModifiedColumns] [varchar](max) NULL,
	[LiveRecOID] [dbo].[objectID] NULL,
	[SequenceNo] [dbo].[objectID] NULL,
	[ValuerContactDirectNumber] [varchar](50) NULL,
	[AddressDetailsOID] [dbo].[objectID] NULL,
	[PersonalContactNumber] [varchar](50) NULL,
	[ValuerBranchAddress] [varchar](50) NULL,
	[ReasonForZeroValuationTypeOID] [dbo].[objectID] NULL,
	[SecurityOwnedAssetDetailsOID] [dbo].[objectID] NULL,
	[AssetResidualValueTypeOID] [dbo].[objectID] NULL,
	[IsResidualValuationGuaranteeInPlace] [bit] NULL,
	[LatestIndexationOID] [int] NULL,
	[SourceOfIndexedValuation] [decimal](38, 5) NULL,
	[SourceOfIndexationDate] [datetime] NULL,
	[IsInternalValuation] [bit] NULL,
 CONSTRAINT [PK_SecurityPropertyValuationDetails] PRIMARY KEY CLUSTERED 
(
	[OID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[SecurityPropertyValuationDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityPropertyValuationDetails_AssetResidualValueType] FOREIGN KEY([AssetResidualValueTypeOID])
REFERENCES [dbo].[AssetResidualValueType] ([OID])
GO

ALTER TABLE [dbo].[SecurityPropertyValuationDetails] CHECK CONSTRAINT [FK_SecurityPropertyValuationDetails_AssetResidualValueType]
GO

ALTER TABLE [dbo].[SecurityPropertyValuationDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityPropertyValuationDetails_SecurityAddressDetails] FOREIGN KEY([AddressDetailsOID])
REFERENCES [dbo].[SecurityAddressDetails] ([OID])
GO

ALTER TABLE [dbo].[SecurityPropertyValuationDetails] CHECK CONSTRAINT [FK_SecurityPropertyValuationDetails_SecurityAddressDetails]
GO

ALTER TABLE [dbo].[SecurityPropertyValuationDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityPropertyValuationDetails_SecurityMethodOfValuationType] FOREIGN KEY([ValuationMethodOID])
REFERENCES [dbo].[SecurityValuationMethodType] ([OID])
GO

ALTER TABLE [dbo].[SecurityPropertyValuationDetails] CHECK CONSTRAINT [FK_SecurityPropertyValuationDetails_SecurityMethodOfValuationType]
GO

ALTER TABLE [dbo].[SecurityPropertyValuationDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityPropertyValuationDetails_SecurityOwnedAssetDetails] FOREIGN KEY([SecurityOwnedAssetDetailsOID])
REFERENCES [dbo].[SecurityOwnedAssetDetails] ([OID])
GO

ALTER TABLE [dbo].[SecurityPropertyValuationDetails] CHECK CONSTRAINT [FK_SecurityPropertyValuationDetails_SecurityOwnedAssetDetails]
GO

ALTER TABLE [dbo].[SecurityPropertyValuationDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityPropertyValuationDetails_SecurityPropertyDetails] FOREIGN KEY([SecurityPropertyDetailsOID])
REFERENCES [dbo].[SecurityPropertyDetails] ([OID])
GO

ALTER TABLE [dbo].[SecurityPropertyValuationDetails] CHECK CONSTRAINT [FK_SecurityPropertyValuationDetails_SecurityPropertyDetails]
GO

ALTER TABLE [dbo].[SecurityPropertyValuationDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityPropertyValuationDetails_SecurityReasonForZeroValuationType] FOREIGN KEY([ReasonForZeroValuationTypeOID])
REFERENCES [dbo].[SecurityReasonForZeroValuationType] ([OID])
GO

ALTER TABLE [dbo].[SecurityPropertyValuationDetails] CHECK CONSTRAINT [FK_SecurityPropertyValuationDetails_SecurityReasonForZeroValuationType]
GO

ALTER TABLE [dbo].[SecurityPropertyValuationDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityPropertyValuationDetails_SecuritySourceOfValuationType] FOREIGN KEY([SourceOID])
REFERENCES [dbo].[SecurityValuationSourceType] ([OID])
GO

ALTER TABLE [dbo].[SecurityPropertyValuationDetails] CHECK CONSTRAINT [FK_SecurityPropertyValuationDetails_SecuritySourceOfValuationType]
GO

ALTER TABLE [dbo].[SecurityPropertyValuationDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityPropertyValuationDetails_SecurityValuationReasonForDissatisfactionType] FOREIGN KEY([DissatisfactionReasonOID])
REFERENCES [dbo].[SecurityValuationDissatisfactionReasonType] ([OID])
GO

ALTER TABLE [dbo].[SecurityPropertyValuationDetails] CHECK CONSTRAINT [FK_SecurityPropertyValuationDetails_SecurityValuationReasonForDissatisfactionType]
GO

ALTER TABLE [dbo].[SecurityPropertyValuationDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityPropertyValuationDetails_SecurityValuerNameType] FOREIGN KEY([ValuerNameOID])
REFERENCES [dbo].[SecurityValuerNameType] ([OID])
GO

ALTER TABLE [dbo].[SecurityPropertyValuationDetails] CHECK CONSTRAINT [FK_SecurityPropertyValuationDetails_SecurityValuerNameType]
GO


