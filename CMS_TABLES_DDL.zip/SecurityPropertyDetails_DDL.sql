USE [CMSDB]
GO

/****** Object:  Table [dbo].[SecurityPropertyDetails]    Script Date: 16/01/2023 14:32:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SecurityPropertyDetails](
	[OID] [dbo].[objectID] IDENTITY(1,1) NOT NULL,
	[Datecreated] [datetime] NOT NULL,
	[Version] [datetime] NOT NULL,
	[SecurityGeneralOID] [dbo].[objectID] NULL,
	[SecurityHeritableOID] [dbo].[objectID] NULL,
	[SecurityHASOID] [dbo].[objectID] NULL,
	[PropertyTypeOID] [dbo].[objectID] NULL,
	[AddressOID] [dbo].[objectID] NULL,
	[AgriPercent] [dbo].[percentage] NULL,
	[StudentAccPercent] [dbo].[percentage] NULL,
	[CommRetailPercent] [dbo].[percentage] NULL,
	[CommOfficePercent] [dbo].[percentage] NULL,
	[CommIndustrialPercent] [dbo].[percentage] NULL,
	[CommNursingHomePercent] [dbo].[percentage] NULL,
	[CommHotelPercent] [dbo].[percentage] NULL,
	[ResidentialPercent] [dbo].[percentage] NULL,
	[TotalPercent] [dbo].[percentage] NULL,
	[PercentOwned] [dbo].[percentage] NULL,
	[SchemeTypeOID] [dbo].[objectID] NULL,
	[PropertyLocationOID] [dbo].[objectID] NULL,
	[PropertyStatusOID] [dbo].[objectID] NULL,
	[DemolitionDate] [datetime] NULL,
	[RTBDeedRecdDate] [datetime] NULL,
	[SoldRTBDate] [datetime] NULL,
	[RTBFundRecdDate] [datetime] NULL,
	[PropertyManagedBy] [dbo].[descriptionString] NULL,
	[UPRNCode] [dbo].[descriptionString] NULL,
	[Comments] [dbo].[descriptionString] NULL,
	[IsIndexationInEffect] [bit] NULL,
	[FairMarketIndexationValue] [decimal](38, 10) NULL,
	[FairMarketIndexationDate] [datetime] NULL,
	[GrantorSignedDate] [datetime] NULL,
	[SecurityMadeAvailableDate] [datetime] NULL,
	[RegistrationDate] [datetime] NULL,
	[HeritableChargeTypeOID] [dbo].[objectID] NULL,
	[OtherHeritableCharge] [dbo].[descriptionString] NULL,
	[PropPartOfLSVT] [bit] NULL,
	[LiveRecOID] [dbo].[objectID] NULL,
	[DraftModifiedColumns] [varchar](max) NULL,
	[DeleteAction] [bit] NULL,
	[IsUpdated] [bit] NULL,
	[FormNumber] [varchar](20) NULL,
	[LeaseExpiryDate] [datetime] NULL,
 CONSTRAINT [PK_SecurityPropertyDetails] PRIMARY KEY CLUSTERED 
(
	[OID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[SecurityPropertyDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityPropertyDetails_SecurityAddressDetails] FOREIGN KEY([AddressOID])
REFERENCES [dbo].[SecurityAddressDetails] ([OID])
GO

ALTER TABLE [dbo].[SecurityPropertyDetails] CHECK CONSTRAINT [FK_SecurityPropertyDetails_SecurityAddressDetails]
GO

ALTER TABLE [dbo].[SecurityPropertyDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityPropertyDetails_SecurityGeneral] FOREIGN KEY([SecurityGeneralOID])
REFERENCES [dbo].[SecurityGeneral] ([OID])
GO

ALTER TABLE [dbo].[SecurityPropertyDetails] CHECK CONSTRAINT [FK_SecurityPropertyDetails_SecurityGeneral]
GO

ALTER TABLE [dbo].[SecurityPropertyDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityPropertyDetails_SecurityHASDetails] FOREIGN KEY([SecurityHASOID])
REFERENCES [dbo].[SecurityHASDetails] ([OID])
GO

ALTER TABLE [dbo].[SecurityPropertyDetails] CHECK CONSTRAINT [FK_SecurityPropertyDetails_SecurityHASDetails]
GO

ALTER TABLE [dbo].[SecurityPropertyDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityPropertyDetails_SecurityHeritableChargeType] FOREIGN KEY([HeritableChargeTypeOID])
REFERENCES [dbo].[SecurityHeritableChargeType] ([OID])
GO

ALTER TABLE [dbo].[SecurityPropertyDetails] CHECK CONSTRAINT [FK_SecurityPropertyDetails_SecurityHeritableChargeType]
GO

ALTER TABLE [dbo].[SecurityPropertyDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityPropertyDetails_SecurityHeritableDetails] FOREIGN KEY([SecurityHeritableOID])
REFERENCES [dbo].[SecurityHeritableDetails] ([OID])
GO

ALTER TABLE [dbo].[SecurityPropertyDetails] CHECK CONSTRAINT [FK_SecurityPropertyDetails_SecurityHeritableDetails]
GO

ALTER TABLE [dbo].[SecurityPropertyDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityPropertyDetails_SecurityPropertyLocationType] FOREIGN KEY([PropertyLocationOID])
REFERENCES [dbo].[SecurityPropertyLocationType] ([OID])
GO

ALTER TABLE [dbo].[SecurityPropertyDetails] CHECK CONSTRAINT [FK_SecurityPropertyDetails_SecurityPropertyLocationType]
GO

ALTER TABLE [dbo].[SecurityPropertyDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityPropertyDetails_SecurityPropertyType] FOREIGN KEY([PropertyTypeOID])
REFERENCES [dbo].[SecurityPropertyType] ([OID])
GO

ALTER TABLE [dbo].[SecurityPropertyDetails] CHECK CONSTRAINT [FK_SecurityPropertyDetails_SecurityPropertyType]
GO

ALTER TABLE [dbo].[SecurityPropertyDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityPropertyDetails_SecuritySchemeType] FOREIGN KEY([SchemeTypeOID])
REFERENCES [dbo].[SecuritySchemeType] ([OID])
GO

ALTER TABLE [dbo].[SecurityPropertyDetails] CHECK CONSTRAINT [FK_SecurityPropertyDetails_SecuritySchemeType]
GO


