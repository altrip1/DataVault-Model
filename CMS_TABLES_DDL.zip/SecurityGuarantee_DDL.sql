USE [CMSDB]
GO

/****** Object:  Table [dbo].[SecurityGuarantee]    Script Date: 16/01/2023 14:26:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SecurityGuarantee](
	[OID] [dbo].[objectID] IDENTITY(1,1) NOT NULL,
	[Datecreated] [datetime] NOT NULL,
	[Version] [datetime] NOT NULL,
	[LiveRecOID] [dbo].[objectID] NULL,
	[SecurityGeneralOID] [dbo].[objectID] NOT NULL,
	[GuaranteeTypeOID] [dbo].[objectID] NULL,
	[OtherType] [dbo].[descriptionString] NULL,
	[FinancialAssistanceOID] [dbo].[objectID] NULL,
	[CommBenefitOID] [dbo].[objectID] NULL,
	[ReasonNoCommBenefit] [dbo].[descriptionString] NULL,
	[EstimatedCurrValue] [decimal](38, 10) NULL,
	[ReducingSum] [bit] NULL,
	[PercentCoverageOID] [dbo].[objectID] NULL,
	[SupportingCollateral] [bit] NULL,
	[WasILAtakenOID] [dbo].[objectID] NULL,
 CONSTRAINT [PK_SecurityGuarantee] PRIMARY KEY CLUSTERED 
(
	[OID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[SecurityGuarantee]  WITH CHECK ADD  CONSTRAINT [FK_SecurityGuarantee_CommonChoiceType] FOREIGN KEY([CommBenefitOID])
REFERENCES [dbo].[CommonChoiceType] ([OID])
GO

ALTER TABLE [dbo].[SecurityGuarantee] CHECK CONSTRAINT [FK_SecurityGuarantee_CommonChoiceType]
GO

ALTER TABLE [dbo].[SecurityGuarantee]  WITH CHECK ADD  CONSTRAINT [FK_SecurityGuarantee_SecurityFinancialAssistanceType] FOREIGN KEY([FinancialAssistanceOID])
REFERENCES [dbo].[SecurityFinancialAssistanceType] ([OID])
GO

ALTER TABLE [dbo].[SecurityGuarantee] CHECK CONSTRAINT [FK_SecurityGuarantee_SecurityFinancialAssistanceType]
GO

ALTER TABLE [dbo].[SecurityGuarantee]  WITH CHECK ADD  CONSTRAINT [FK_SecurityGuarantee_SecurityGeneral] FOREIGN KEY([SecurityGeneralOID])
REFERENCES [dbo].[SecurityGeneral] ([OID])
GO

ALTER TABLE [dbo].[SecurityGuarantee] CHECK CONSTRAINT [FK_SecurityGuarantee_SecurityGeneral]
GO

ALTER TABLE [dbo].[SecurityGuarantee]  WITH CHECK ADD  CONSTRAINT [FK_SecurityGuarantee_SecurityGuaranteeType] FOREIGN KEY([GuaranteeTypeOID])
REFERENCES [dbo].[SecurityGuaranteeType] ([OID])
GO

ALTER TABLE [dbo].[SecurityGuarantee] CHECK CONSTRAINT [FK_SecurityGuarantee_SecurityGuaranteeType]
GO

ALTER TABLE [dbo].[SecurityGuarantee]  WITH CHECK ADD  CONSTRAINT [FK_SecurityGuarantee_SecurityPercentCoverageType] FOREIGN KEY([PercentCoverageOID])
REFERENCES [dbo].[SecurityPercentCoverageType] ([OID])
GO

ALTER TABLE [dbo].[SecurityGuarantee] CHECK CONSTRAINT [FK_SecurityGuarantee_SecurityPercentCoverageType]
GO

ALTER TABLE [dbo].[SecurityGuarantee]  WITH CHECK ADD  CONSTRAINT [FK_SecurityGuarantee_WasILAtakenOID_CommonChoiceType] FOREIGN KEY([WasILAtakenOID])
REFERENCES [dbo].[CommonChoiceType] ([OID])
GO

ALTER TABLE [dbo].[SecurityGuarantee] CHECK CONSTRAINT [FK_SecurityGuarantee_WasILAtakenOID_CommonChoiceType]
GO


