USE [CMSDB]
GO

/****** Object:  Table [dbo].[SecurityGeneral]    Script Date: 16/01/2023 14:22:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SecurityGeneral](
	[OID] [dbo].[objectID] IDENTITY(1,1) NOT NULL,
	[Datecreated] [datetime] NOT NULL,
	[Version] [datetime] NOT NULL,
	[LegalEntityOID] [dbo].[objectID] NOT NULL,
	[LiveRecOID] [dbo].[objectID] NULL,
	[LegalEntityName] [dbo].[descriptionString] NULL,
	[OwnerName] [dbo].[descriptionString] NULL,
	[SecurityTypeOID] [dbo].[objectID] NOT NULL,
	[SIFAssetType] [dbo].[descriptionString] NULL,
	[SecurityAvailabilityOID] [dbo].[objectID] NULL,
	[CurrencyOID] [dbo].[objectID] NOT NULL,
	[LegalJurisdictionOID] [dbo].[objectID] NULL,
	[SecurityEndDateOID] [dbo].[objectID] NOT NULL,
	[SpecificEndDate] [datetime] NULL,
	[SecurityStatusOID] [dbo].[objectID] NOT NULL,
	[GrantorName] [text] NULL,
	[SecurityMadeAvailableDate] [datetime] NULL,
	[PartialDischarge] [bit] NULL,
	[GrantorSignedDate] [datetime] NULL,
	[RegistrationDate] [datetime] NULL,
	[Syndicated] [bit] NULL,
	[SecurityAgentsOrTrustee] [dbo].[objectID] NULL,
	[AgentTrustee] [dbo].[objectID] NULL,
	[OtherSecurityAgentTrustee] [dbo].[descriptionString] NULL,
	[OtherSecurityAgentTrusteeId] [dbo].[objectID] NULL,
	[SecurityBasisOfAllocationOID] [dbo].[objectID] NULL,
	[SecurityAllocatedSpecificValue] [decimal](38, 10) NULL,
	[SecurityAllocatedPercentageValue] [decimal](38, 10) NULL,
	[ParticipantBanks] [text] NULL,
	[ForeignLegalOpinionObtained] [bit] NULL,
	[InsolvencyAgentID] [int] NULL,
	[InsolvencyAgentName] [dbo].[descriptionString] NULL,
	[ForcedSaleValue] [decimal](38, 10) NULL,
	[DateOfValuation] [datetime] NULL,
	[ValuedById] [int] NULL,
	[ValuedByName] [dbo].[descriptionString] NULL,
	[ReasonValueDifferent] [dbo].[descriptionString] NULL,
	[ExpectedClearanceDate] [datetime] NULL,
	[GrossValueRecovered] [decimal](38, 10) NULL,
	[NetValueRecovered] [decimal](38, 10) NULL,
	[LBGShareRecovered] [decimal](38, 10) NULL,
	[DateCollateralValueRecovered] [datetime] NULL,
	[IsAssetInsured] [char](1) NULL,
	[DoesSecMeetCreditRiskMitiPolicy] [bit] NULL,
	[AssetRefNo] [varchar](50) NULL,
	[MigratedRec] [bit] NULL,
	[CreatedBy] [dbo].[CMSUserID] NULL,
	[UploadedRec] [bit] NULL,
	[DownloadFlg] [bit] NULL,
	[DraftSecurityStatusTypeOID] [dbo].[objectID] NULL,
	[SecurityStatusChangedDate] [datetime] NULL,
	[IPAppointedDate] [datetime] NULL,
	[PulledFromNexus] [bit] NULL,
	[IsSIFAsset] [bit] NULL,
	[LastUpdatedBy] [dbo].[CMSUserID] NULL,
	[SecurityCoversOID] [dbo].[objectID] NULL,
	[SpecificSum] [decimal](38, 10) NULL,
	[BackBookChecked] [bit] NULL,
	[GrossValue] [decimal](38, 10) NULL,
	[SecurityDescription] [dbo].[descriptionString] NULL,
	[DraftCreatedBy] [dbo].[CMSUserID] NULL,
	[LiveSecurityStatusTypeOID] [dbo].[objectID] NULL,
	[BankingLicenceOID] [dbo].[objectID] NOT NULL,
	[CountryLimitationExists] [bit] NULL,
	[IsCrossCollateralisedOtherBank] [bit] NULL,
	[MCOBRegulated] [bit] NULL,
	[IsGroupCollateral] [bit] NOT NULL,
	[OriginatingSystemOID] [dbo].[objectID] NOT NULL,
	[LBGSecurityValue] [decimal](38, 10) NULL,
	[DataAttested] [bit] NOT NULL,
	[AttestedBy] [varchar](100) NULL,
	[AttestedDate] [datetime] NULL,
 CONSTRAINT [PK_SecurityGeneral] PRIMARY KEY CLUSTERED 
(
	[OID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[SecurityGeneral] ADD  CONSTRAINT [DF__SecurityGeneral__DataAttested]  DEFAULT ((0)) FOR [DataAttested]
GO

ALTER TABLE [dbo].[SecurityGeneral]  WITH CHECK ADD  CONSTRAINT [FK_SecurityGeneral_AgentOrTrusteeType] FOREIGN KEY([AgentTrustee])
REFERENCES [dbo].[AgentOrTrusteeType] ([OID])
GO

ALTER TABLE [dbo].[SecurityGeneral] CHECK CONSTRAINT [FK_SecurityGeneral_AgentOrTrusteeType]
GO

ALTER TABLE [dbo].[SecurityGeneral]  WITH CHECK ADD  CONSTRAINT [FK_SecurityGeneral_CommonChoiceType] FOREIGN KEY([SecurityAgentsOrTrustee])
REFERENCES [dbo].[CommonChoiceType] ([OID])
GO

ALTER TABLE [dbo].[SecurityGeneral] CHECK CONSTRAINT [FK_SecurityGeneral_CommonChoiceType]
GO

ALTER TABLE [dbo].[SecurityGeneral]  WITH CHECK ADD  CONSTRAINT [FK_SecurityGeneral_Currency] FOREIGN KEY([CurrencyOID])
REFERENCES [dbo].[Currency] ([OID])
GO

ALTER TABLE [dbo].[SecurityGeneral] CHECK CONSTRAINT [FK_SecurityGeneral_Currency]
GO

ALTER TABLE [dbo].[SecurityGeneral]  WITH CHECK ADD  CONSTRAINT [FK_SecurityGeneral_DraftSecurityStatusType] FOREIGN KEY([DraftSecurityStatusTypeOID])
REFERENCES [dbo].[DraftSecurityStatusType] ([OID])
GO

ALTER TABLE [dbo].[SecurityGeneral] CHECK CONSTRAINT [FK_SecurityGeneral_DraftSecurityStatusType]
GO

ALTER TABLE [dbo].[SecurityGeneral]  WITH CHECK ADD  CONSTRAINT [FK_SecurityGeneral_LiveSecurityStatusType] FOREIGN KEY([LiveSecurityStatusTypeOID])
REFERENCES [dbo].[SecurityStatusType] ([OID])
GO

ALTER TABLE [dbo].[SecurityGeneral] CHECK CONSTRAINT [FK_SecurityGeneral_LiveSecurityStatusType]
GO

ALTER TABLE [dbo].[SecurityGeneral]  WITH CHECK ADD  CONSTRAINT [FK_SecurityGeneral_OriginatingSystemOID] FOREIGN KEY([OriginatingSystemOID])
REFERENCES [dbo].[OriginatingSystem] ([OID])
GO

ALTER TABLE [dbo].[SecurityGeneral] CHECK CONSTRAINT [FK_SecurityGeneral_OriginatingSystemOID]
GO

ALTER TABLE [dbo].[SecurityGeneral]  WITH CHECK ADD  CONSTRAINT [FK_SecurityGeneral_PrevailingLawType] FOREIGN KEY([LegalJurisdictionOID])
REFERENCES [dbo].[SecurityPrevailingLawType] ([OID])
GO

ALTER TABLE [dbo].[SecurityGeneral] CHECK CONSTRAINT [FK_SecurityGeneral_PrevailingLawType]
GO

ALTER TABLE [dbo].[SecurityGeneral]  WITH CHECK ADD  CONSTRAINT [FK_SecurityGeneral_SecurityAvailabilityType] FOREIGN KEY([SecurityAvailabilityOID])
REFERENCES [dbo].[SecurityAvailabilityType] ([OID])
GO

ALTER TABLE [dbo].[SecurityGeneral] CHECK CONSTRAINT [FK_SecurityGeneral_SecurityAvailabilityType]
GO

ALTER TABLE [dbo].[SecurityGeneral]  WITH CHECK ADD  CONSTRAINT [FK_SecurityGeneral_SecurityBankingLicenceType] FOREIGN KEY([BankingLicenceOID])
REFERENCES [dbo].[SecurityBankingLicenceType] ([OID])
GO

ALTER TABLE [dbo].[SecurityGeneral] CHECK CONSTRAINT [FK_SecurityGeneral_SecurityBankingLicenceType]
GO

ALTER TABLE [dbo].[SecurityGeneral]  WITH CHECK ADD  CONSTRAINT [FK_SecurityGeneral_SecurityBasisOfAllocationType] FOREIGN KEY([SecurityBasisOfAllocationOID])
REFERENCES [dbo].[SecurityAllocationBasisType] ([OID])
GO

ALTER TABLE [dbo].[SecurityGeneral] CHECK CONSTRAINT [FK_SecurityGeneral_SecurityBasisOfAllocationType]
GO

ALTER TABLE [dbo].[SecurityGeneral]  WITH CHECK ADD  CONSTRAINT [FK_SecurityGeneral_SecurityCoversType] FOREIGN KEY([SecurityCoversOID])
REFERENCES [dbo].[SecurityCoversType] ([OID])
GO

ALTER TABLE [dbo].[SecurityGeneral] CHECK CONSTRAINT [FK_SecurityGeneral_SecurityCoversType]
GO

ALTER TABLE [dbo].[SecurityGeneral]  WITH CHECK ADD  CONSTRAINT [FK_SecurityGeneral_SecurityEndDateType] FOREIGN KEY([SecurityEndDateOID])
REFERENCES [dbo].[SecurityEndDateType] ([OID])
GO

ALTER TABLE [dbo].[SecurityGeneral] CHECK CONSTRAINT [FK_SecurityGeneral_SecurityEndDateType]
GO

ALTER TABLE [dbo].[SecurityGeneral]  WITH CHECK ADD  CONSTRAINT [FK_SecurityGeneral_SecurityStatusType] FOREIGN KEY([SecurityStatusOID])
REFERENCES [dbo].[SecurityStatusType] ([OID])
GO

ALTER TABLE [dbo].[SecurityGeneral] CHECK CONSTRAINT [FK_SecurityGeneral_SecurityStatusType]
GO

ALTER TABLE [dbo].[SecurityGeneral]  WITH CHECK ADD  CONSTRAINT [FK_SecurityGeneral_SecurityType] FOREIGN KEY([SecurityTypeOID])
REFERENCES [dbo].[SecurityType] ([OID])
GO

ALTER TABLE [dbo].[SecurityGeneral] CHECK CONSTRAINT [FK_SecurityGeneral_SecurityType]
GO


