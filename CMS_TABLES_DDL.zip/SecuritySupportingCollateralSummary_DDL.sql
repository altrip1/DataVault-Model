USE [CMSDB]
GO

/****** Object:  Table [dbo].[SecuritySupportingCollateralSummary]    Script Date: 16/01/2023 14:29:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SecuritySupportingCollateralSummary](
	[OID] [dbo].[objectID] IDENTITY(1,1) NOT NULL,
	[Datecreated] [datetime] NOT NULL,
	[Version] [datetime] NOT NULL,
	[SecurityGuaranteeOID] [dbo].[objectID] NULL,
	[SecurityCounterIndemnityOID] [dbo].[objectID] NULL,
	[SupportingSecOID] [dbo].[objectID] NULL,
 CONSTRAINT [PK_SecuritySupportingCollateralSummary] PRIMARY KEY CLUSTERED 
(
	[OID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[SecuritySupportingCollateralSummary]  WITH CHECK ADD  CONSTRAINT [FK_SecuritySupportingCollateralSummary_SecurityCounterIndemnityDetails] FOREIGN KEY([SecurityCounterIndemnityOID])
REFERENCES [dbo].[SecurityCounterIndemnityDetails] ([OID])
GO

ALTER TABLE [dbo].[SecuritySupportingCollateralSummary] CHECK CONSTRAINT [FK_SecuritySupportingCollateralSummary_SecurityCounterIndemnityDetails]
GO

ALTER TABLE [dbo].[SecuritySupportingCollateralSummary]  WITH CHECK ADD  CONSTRAINT [FK_SecuritySupportingCollateralSummary_SecurityGeneral] FOREIGN KEY([SupportingSecOID])
REFERENCES [dbo].[SecurityGeneral] ([OID])
GO

ALTER TABLE [dbo].[SecuritySupportingCollateralSummary] CHECK CONSTRAINT [FK_SecuritySupportingCollateralSummary_SecurityGeneral]
GO

ALTER TABLE [dbo].[SecuritySupportingCollateralSummary]  WITH CHECK ADD  CONSTRAINT [FK_SecuritySupportingCollateralSummary_SecurityGuarantee] FOREIGN KEY([SecurityGuaranteeOID])
REFERENCES [dbo].[SecurityGuarantee] ([OID])
GO

ALTER TABLE [dbo].[SecuritySupportingCollateralSummary] CHECK CONSTRAINT [FK_SecuritySupportingCollateralSummary_SecurityGuarantee]
GO


