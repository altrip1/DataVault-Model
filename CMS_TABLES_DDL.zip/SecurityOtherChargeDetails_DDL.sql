USE [CMSDB]
GO

/****** Object:  Table [dbo].[SecurityOtherChargeDetails]    Script Date: 16/01/2023 14:34:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SecurityOtherChargeDetails](
	[OID] [dbo].[objectID] IDENTITY(1,1) NOT NULL,
	[Datecreated] [datetime] NOT NULL,
	[Version] [datetime] NOT NULL,
	[SecurityGeneralOID] [dbo].[objectID] NOT NULL,
	[LiveRecOID] [dbo].[objectID] NULL,
	[SecurityPropertyDetailsOID] [dbo].[objectID] NULL,
	[OrderNumber] [int] NULL,
	[Amount] [decimal](38, 10) NULL,
	[NexusPartyTypeOID] [dbo].[objectID] NULL,
	[PartyNameLegalEntityID] [int] NULL,
	[PartyName] [dbo].[descriptionString] NULL,
	[EndDateTypeOID] [dbo].[objectID] NULL,
	[SpecificDate] [datetime] NULL,
	[Details] [dbo].[descriptionString] NULL,
	[FormNumber] [varchar](200) NULL,
	[RankingCoversTypeOID] [dbo].[objectID] NULL,
 CONSTRAINT [PK_SecurityOtherChargeDetails] PRIMARY KEY CLUSTERED 
(
	[OID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[SecurityOtherChargeDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityOtherChargeDetails_SecurityEndDateType] FOREIGN KEY([EndDateTypeOID])
REFERENCES [dbo].[SecurityEndDateType] ([OID])
GO

ALTER TABLE [dbo].[SecurityOtherChargeDetails] CHECK CONSTRAINT [FK_SecurityOtherChargeDetails_SecurityEndDateType]
GO

ALTER TABLE [dbo].[SecurityOtherChargeDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityOtherChargeDetails_securityGeneral] FOREIGN KEY([SecurityGeneralOID])
REFERENCES [dbo].[SecurityGeneral] ([OID])
GO

ALTER TABLE [dbo].[SecurityOtherChargeDetails] CHECK CONSTRAINT [FK_SecurityOtherChargeDetails_securityGeneral]
GO

ALTER TABLE [dbo].[SecurityOtherChargeDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityOtherChargeDetails_SecurityNexusPartyType] FOREIGN KEY([NexusPartyTypeOID])
REFERENCES [dbo].[SecurityNexusPartyType] ([OID])
GO

ALTER TABLE [dbo].[SecurityOtherChargeDetails] CHECK CONSTRAINT [FK_SecurityOtherChargeDetails_SecurityNexusPartyType]
GO

ALTER TABLE [dbo].[SecurityOtherChargeDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityOtherChargeDetails_SecurityPropertyDetails] FOREIGN KEY([SecurityPropertyDetailsOID])
REFERENCES [dbo].[SecurityPropertyDetails] ([OID])
GO

ALTER TABLE [dbo].[SecurityOtherChargeDetails] CHECK CONSTRAINT [FK_SecurityOtherChargeDetails_SecurityPropertyDetails]
GO

ALTER TABLE [dbo].[SecurityOtherChargeDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityOtherChargeDetails_SecurityRankingCoversType] FOREIGN KEY([RankingCoversTypeOID])
REFERENCES [dbo].[SecurityRankingCoversType] ([OID])
GO

ALTER TABLE [dbo].[SecurityOtherChargeDetails] CHECK CONSTRAINT [FK_SecurityOtherChargeDetails_SecurityRankingCoversType]
GO


