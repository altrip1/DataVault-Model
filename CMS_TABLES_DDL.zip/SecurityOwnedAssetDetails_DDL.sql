USE [CMSDB]
GO

/****** Object:  Table [dbo].[SecurityOwnedAssetDetails]    Script Date: 16/01/2023 14:30:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SecurityOwnedAssetDetails](
	[OID] [dbo].[objectID] IDENTITY(1,1) NOT NULL,
	[Datecreated] [datetime] NOT NULL,
	[Version] [datetime] NOT NULL,
	[SecurityGeneralOID] [dbo].[objectID] NOT NULL,
	[LiveRecOID] [dbo].[objectID] NULL,
	[AssetTypeOID] [dbo].[objectID] NOT NULL,
	[AssetSubTypeOID] [dbo].[objectID] NOT NULL,
	[FilenetRefNo] [nvarchar](50) NULL,
	[AssetRefID] [nvarchar](50) NULL,
	[LocationofAssetOID] [dbo].[objectID] NULL,
	[AssetOwnershipTypeOID] [dbo].[objectID] NULL,
	[IsMutipleAsset] [bit] NULL,
	[NumberOfAsset] [dbo].[objectID] NULL,
	[AssetDescription] [dbo].[descriptionString] NULL,
	[BankingLicenceOID] [dbo].[objectID] NULL,
 CONSTRAINT [PK_SecurityOwnedAssetDetails] PRIMARY KEY CLUSTERED 
(
	[OID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[SecurityOwnedAssetDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityOwnedAssetDetails_AssetOwnershipType] FOREIGN KEY([AssetOwnershipTypeOID])
REFERENCES [dbo].[AssetOwnershipType] ([OID])
GO

ALTER TABLE [dbo].[SecurityOwnedAssetDetails] CHECK CONSTRAINT [FK_SecurityOwnedAssetDetails_AssetOwnershipType]
GO

ALTER TABLE [dbo].[SecurityOwnedAssetDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityOwnedAssetDetails_AssetSubType] FOREIGN KEY([AssetSubTypeOID])
REFERENCES [dbo].[AssetSubType] ([AssetSubTypeOID])
GO

ALTER TABLE [dbo].[SecurityOwnedAssetDetails] CHECK CONSTRAINT [FK_SecurityOwnedAssetDetails_AssetSubType]
GO

ALTER TABLE [dbo].[SecurityOwnedAssetDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityOwnedAssetDetails_AssetType] FOREIGN KEY([AssetTypeOID])
REFERENCES [dbo].[AssetType] ([OID])
GO

ALTER TABLE [dbo].[SecurityOwnedAssetDetails] CHECK CONSTRAINT [FK_SecurityOwnedAssetDetails_AssetType]
GO

ALTER TABLE [dbo].[SecurityOwnedAssetDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityOwnedAssetDetails_SecurityGeneral] FOREIGN KEY([SecurityGeneralOID])
REFERENCES [dbo].[SecurityGeneral] ([OID])
GO

ALTER TABLE [dbo].[SecurityOwnedAssetDetails] CHECK CONSTRAINT [FK_SecurityOwnedAssetDetails_SecurityGeneral]
GO

ALTER TABLE [dbo].[SecurityOwnedAssetDetails]  WITH CHECK ADD  CONSTRAINT [FK_SecurityOwnedAssetDetails_SecurityPrevailingLawType] FOREIGN KEY([LocationofAssetOID])
REFERENCES [dbo].[SecurityPrevailingLawType] ([OID])
GO

ALTER TABLE [dbo].[SecurityOwnedAssetDetails] CHECK CONSTRAINT [FK_SecurityOwnedAssetDetails_SecurityPrevailingLawType]
GO


